
# Grass Thatching Business - Single Page Site

This is a lightweight, SEO-friendly single-page website template for a grass thatching business.

## How to use
- Edit `index.html` to change text, images, and contact info.
- Deploy with GitHub Pages or Netlify (no build step needed).

## Sections
- Home, About, Services, Gallery, Blog, Contact

## License
Feel free to use and modify for your project submissions.
